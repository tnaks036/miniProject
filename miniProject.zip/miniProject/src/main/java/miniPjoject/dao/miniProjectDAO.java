package miniPjoject.dao;

import java.util.List;

public interface miniProjectDAO {
	
	public List<miniProjectlist> getList(String food);
	
	public List<miniProjectlist> restaurant(String food);
	
	public List<miniProjectlist> menu(String restaurant);
	
	public int update(Long polls);
}
