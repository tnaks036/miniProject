package miniPjoject.dao;

public class miniProjectlist {
	private String restaurant;
	private String category;
	private String menu;
	private Long price;
	private Long reviews;
	private Long polls;
	private String specification;
	private Long no;
	
	




	public String getRestaurant() {
		return restaurant;
	}






	public void setRestaurant(String restaurant) {
		this.restaurant = restaurant;
	}






	public String getCategory() {
		return category;
	}






	public void setCategory(String category) {
		this.category = category;
	}






	public String getMenu() {
		return menu;
	}






	public void setMenu(String menu) {
		this.menu = menu;
	}






	public Long getPrice() {
		return price;
	}






	public void setPrice(Long price) {
		this.price = price;
	}






	public Long getReviews() {
		return reviews;
	}






	public void setReviews(Long reviews) {
		this.reviews = reviews;
	}






	public Long getPolls() {
		return polls;
	}






	public void setPolls(Long polls) {
		this.polls = polls;
	}






	public String getSpecification() {
		return specification;
	}






	public void setSpecification(String specification) {
		this.specification = specification;
	}






	public Long getNo() {
		return no;
	}






	public void setNo(Long no) {
		this.no = no;
	}






	@Override
	public String toString() {
		return "miniProjectlist [restaurant=" + restaurant + ", category=" + category + ", menu=" + menu + ", price="
				+ price + ", reviews=" + reviews + ", polls=" + polls + ", specification=" + specification + ", no="
				+ no + "]";
	}






	



		
	

}
